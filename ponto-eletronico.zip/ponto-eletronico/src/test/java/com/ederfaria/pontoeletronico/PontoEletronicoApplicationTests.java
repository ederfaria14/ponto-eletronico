package com.ederfaria.pontoeletronico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PontoEletronicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
